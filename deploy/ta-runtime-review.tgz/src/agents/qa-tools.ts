import { Academics } from '../application/services/academics.ts';
import type { TaskEngine } from '../application/task-engine.ts';
import type { Run } from '../domain/model.ts';
import { DomainError, channelKey } from '../domain/model.ts';
import type { TextbookReferences } from '../adapters/knowledge/references.ts';
import type { PageReader } from '../adapters/knowledge/pdf-page.ts';
import type { Knowledge } from '../ports/knowledge.ts';
import type { ToolDefinition, VisualContent } from '../ports/model.ts';
import { describeAttachments, qqImageType } from '../adapters/qq/attachments.ts';
import type { QQAttachmentReader } from '../adapters/qq/attachments.ts';

const str = { type: 'string' };
const integer = { type: 'integer', minimum: 1 };
function tool(name: string, description: string, properties: object, required: string[] = []): ToolDefinition {
  return { type: 'function', function: { name, description, parameters: { type: 'object', properties, required, additionalProperties: false } } };
}
export const qaToolDefinitions = [
  tool('list_assignments', '查本课程学生可见的作业目录及截止日期。多份可能时先澄清。', {}),
  tool('read_assignment', '按目录中的作业 ID 查题面和提交要求。需要核对题图时指定 attachment（从1开始）。', { assignmentId: str, attachment: integer }, ['assignmentId']),
  tool('lookup_textbook', '精确定位本课教材章节/习题/定理编号，例如 2.1节 T2；可按 bookId 选择课程内教材。', { query: str, bookId: str }, ['query']),
  tool('search_textbook', '按概念或方法检索本课教材。结果是定位候选，不能替代精确题号。', { query: str, bookId: str }, ['query']),
  tool('textbook_section', '核对本课教材的具体节号（例如 17.2），返回节标题、子专题、页码与节内摘录。', { sectionId: str, bookId: str }, ['sectionId']),
  tool('view_textbook_page', '查阅本课教材原始 PDF 的物理页，必须使用检索结果中的 bookId 和页码。', { bookId: str, page: integer }, ['bookId','page']),
  tool('read_quoted_message', '读取当前消息明确引用的那一条原消息或助教已发回复。', {}),
  tool('read_qq_image', '查看本次 QQ 消息或其明确引用中的图片。source 为 current 或 quoted，图片序号从 1 开始。', {
    source: { type: 'string', enum: ['current', 'quoted'] }, index: integer,
  }),
];
const positiveInt = (n: unknown): n is number => typeof n === 'number' && Number.isSafeInteger(n) && n > 0;
const image = (metadata: object, url: string): VisualContent[] => [
  { type: 'text', text: JSON.stringify(metadata) },
  { type: 'image_url', image_url: { url } },
];

export class QATools {
  private readonly academics: Academics;
  constructor(privateEngine: TaskEngine, knowledge?: Knowledge, references?: Pick<TextbookReferences, 'lookup'> & Partial<Pick<TextbookReferences, 'sections'>>, pageReader?: PageReader, readAttachment?: QQAttachmentReader) {
    this.engine = privateEngine; this.academics = new Academics(privateEngine);
    this.knowledge = knowledge; this.references = references; this.pageReader = pageReader; this.readAttachment = readAttachment;
  }
  private readonly engine: TaskEngine;
  private readonly knowledge?: Knowledge;
  private readonly references?: Pick<TextbookReferences, 'lookup'> & Partial<Pick<TextbookReferences, 'sections'>>;
  private readonly pageReader?: PageReader;
  private readonly readAttachment?: QQAttachmentReader;

  async call(run: Pick<Run, 'course' | 'history' | 'assignmentReads' | 'knowledgeAnchors'>, name: string, raw: string, signal: AbortSignal, vision: boolean): Promise<string | VisualContent[]> {
    signal.throwIfAborted();
    const { id: courseId, textbookIds = [] } = run.course;
    const event = run.history.at(-1)?.event;
    try {
      if (raw.length > 4000) throw new DomainError('invalid', '参数过长');
      const args = JSON.parse(raw) as Record<string, unknown>;
      const definition = qaToolDefinitions.find(t => t.function.name === name);
      if (!args || typeof args !== 'object' || Array.isArray(args) || !definition) throw new DomainError('invalid', '不支持该工具或参数');
      const properties = (definition.function.parameters as { properties: object }).properties;
      if (Object.keys(args).some(key => !Object.hasOwn(properties, key))) throw new DomainError('invalid', '工具参数包含未授权字段');
      const query = () => {
        if (typeof args.query !== 'string' || !args.query.trim() || args.query.length > 600) throw new DomainError('invalid', '需要明确且简短的检索词');
        return args.query.trim();
      };
      const books = () => {
        if (args.bookId === undefined) return textbookIds;
        if (typeof args.bookId !== 'string' || !textbookIds.includes(args.bookId)) throw new DomainError('forbidden', '教材不属于本课程');
        return [args.bookId];
      };
      const remember = (item: { id: string; revision: number }) => {
        if (!run.assignmentReads) run.assignmentReads = [];
        if (!run.assignmentReads.some(read => read.id === item.id)) run.assignmentReads.push({ id: item.id, revision: item.revision });
      };
      if (name === 'list_assignments') {
        const assignments = this.academics.visibleAssignments(courseId).slice(-30).reverse();
        assignments.forEach(remember);
        return JSON.stringify({ courseId, assignments });
      }
      if (name === 'read_assignment') {
        if (typeof args.assignmentId !== 'string') throw new DomainError('invalid', '缺少作业 ID');
        const a = this.academics.visibleAssignment(courseId, args.assignmentId);
        remember(a);
        const metadata = { id: a.id, title: a.title, revision: a.revision, deadline: a.deadline, instructions: a.instructions,
          attachments: (a.images ?? []).map((file, i) => ({ index: i + 1, name: file.name })) };
        if (args.attachment === undefined) return JSON.stringify(metadata);
        const attachment = positiveInt(args.attachment) && a.images?.[args.attachment - 1];
        if (!attachment) throw new DomainError('not_found', '找不到这张作业题图');
        if (!vision) return JSON.stringify({ ...metadata, error: '当前模型不支持查看题图' });
        return image({ ...metadata, loadedAttachment: args.attachment }, attachment.dataUrl);
      }
      if (name === 'read_quoted_message') {
        const quote = event && this.engine.store.quotedText(event);
        if (!quote) return JSON.stringify({ error: '当前没有可核对的引用原文；请提供题号或重新引用' });
        const { imageId, ...source } = quote;
        const png = imageId && vision ? this.engine.store.teachingImage(courseId, imageId) : undefined;
        const metadata = { ...source, text: quote.text.slice(0, 12000), truncated: quote.text.length > 12000,
          imageLoaded: !!png };
        return png ? image(metadata, 'data:image/png;base64,' + png.toString('base64')) : JSON.stringify(metadata);
      }
      if (name === 'read_qq_image') {
        if (!event || event.channel.kind === 'management' || (args.index !== undefined && !positiveInt(args.index)) ||
          (args.source !== undefined && args.source !== 'current' && args.source !== 'quoted')) throw new DomainError('invalid', '需要当前或引用图片及有效序号');
        const source = args.source === 'quoted' && event.quotedExternalId
          ? this.engine.store.eventByKey(`qq:${channelKey(event.channel)}:${event.quotedExternalId}`)
          : args.source === 'quoted' ? undefined : event;
        if (!source || source.courseId !== courseId || channelKey(source.channel) !== channelKey(event.channel) ||
          (args.source === 'quoted' && source.threadId !== event.threadId)) throw new DomainError('not_found', '本轮没有可读取的引用图片');
        const index = Number(args.index ?? 1);
        const item = source.attachments?.[index - 1];
        if (!item || item.kind !== 'image') return JSON.stringify({ error: '该序号无图片', attachments: describeAttachments(source) });
        if (!vision || !this.readAttachment) throw new DomainError('unavailable', '本轮不能读取 QQ 图片');
        const content = await this.readAttachment(source.channel, item, signal);
        const mediaType = qqImageType(content);
        if (!mediaType || mediaType === 'image/gif') throw new DomainError('invalid', '请将图片转成 PNG、JPEG 或 WebP 后再发');
        return image({ index, name: item.name }, `data:${mediaType};base64,${content.toString('base64')}`);
      }
      if (name === 'lookup_textbook') {
        const bookIds = books(), term = query();
        const quoted = event && this.engine.store.quotedText(event);
        return JSON.stringify(this.references?.lookup(bookIds, term, quoted ? [quoted.text] : [])
          ?? { found: [], error: '教材编号索引不可用' });
      }
      if (name === 'search_textbook') {
        const bookIds = books(), term = query();
        const result = await this.knowledge?.search(bookIds, term, signal);
        if (result) run.knowledgeAnchors = [...new Set([...(run.knowledgeAnchors ?? []), ...result.hits.map(hit => hit.anchor)])].slice(0, 12);
        return JSON.stringify(result ?? { hits: [], error: '教材搜索不可用' });
      }
      if (name === 'textbook_section') {
        const id = args.sectionId;
        if (typeof id !== 'string' || !/^\d{1,3}\.\d{1,3}$/.test(id)) throw new DomainError('invalid', '请提供类似 17.2 的节号');
        const bookIds = books();
        const sections = this.references?.sections?.(bookIds, id) ?? [];
        return JSON.stringify({ sectionId: id, sections, ...(sections.length > 1 ? { ambiguous: true } : {}) });
      }
      const bookIds = books();
      if (typeof args.bookId !== 'string' || !positiveInt(args.page)) throw new DomainError('invalid', '缺少教材 ID 或有效页码');
      if (!vision || !this.pageReader) return JSON.stringify({ error: '本轮不能查看原页', bookId: args.bookId, page: args.page });
      try {
        const url = await this.pageReader(bookIds[0], args.page, signal);
        return image({ bookId: args.bookId, page: args.page, source: '原 PDF 物理页，供本轮核对' }, url);
      } catch {
        signal.throwIfAborted();
        return JSON.stringify({ error: '原 PDF 页图未加载；不可声称看过原页', bookId: args.bookId, page: args.page });
      }
    } catch (error) {
      signal.throwIfAborted();
      if (error instanceof DomainError) return JSON.stringify({ error: error.message });
      if (error instanceof SyntaxError) return JSON.stringify({ error: '工具参数不是完整 JSON' });
      throw error;
    }
  }
}
