import type { Run } from '../domain/model.ts';
import { DomainError } from '../domain/model.ts';
import type { Knowledge, KnowledgeResult } from '../ports/knowledge.ts';
import type { MemoryService, MemorySearch } from '../application/services/memory.ts';
import type { TextbookReferences } from '../adapters/knowledge/references.ts';

export class ContextBuilder {
  memory: MemoryService; knowledge?: Knowledge; references?: TextbookReferences;
  constructor(memory: MemoryService, knowledge?: Knowledge, references?: TextbookReferences) {
    this.memory = memory; this.knowledge = knowledge; this.references = references;
  }
  async build(run: Run, signal: AbortSignal, prefetchTextbook = true) {
    const history = run.history.slice(-12);
    const discussion = history.map(i => ({ eventId: i.event.id, actorId: i.event.actor.id, text: i.event.text }));
    const current = history.at(-1)?.event;
    const latest = current?.text ?? run.task.goal;
    const followup = /^(?:这[题道个里步一]|刚才|那[题道个]|第[一二三四五\d]+问|它|为什么|怎么做|继续|所以|那[么如果]|再|请(?:再|把|展开|详细|用.*(?:举例|说明))|能(?:再|详细)|什么意思|有别的方法)/.test(latest);
    const recent = followup ? history.slice(0, -1).filter(i => current && current.receivedAt - i.event.receivedAt < 30 * 60_000) : [];
    const earlier = (current?.quoted ? history.slice(0, -1) : recent).map(i => i.event.text);
    let exact = prefetchTextbook ? this.references?.lookup(run.course.textbookIds ?? [], latest, earlier) : undefined;
    if (prefetchTextbook && !exact?.requested.length && (current?.quoted || followup)) {
      for (let i = earlier.length - 1; i >= 0; i--) {
        const candidate = this.references?.lookup(run.course.textbookIds ?? [], earlier[i], earlier.slice(0, i));
        if (candidate?.requested.length) { exact = candidate; break; }
      }
    }
    const query = (earlier.length && latest.length < 45 ? earlier.at(-1) + '\n' + latest : latest).slice(-6000);
    const knowledge: KnowledgeResult = prefetchTextbook && this.knowledge && !exact?.requested.length
      ? await this.knowledge.search(run.course.textbookIds ?? [], query, signal)
      : { hits: [], topics: [], mode: 'keyword', warnings: prefetchTextbook && !this.knowledge ? ['尚未接入教材检索'] : [] };
    const anchors = knowledge.hits.map(hit => hit.anchor);
    const memories: MemorySearch = await this.memory.search(run, query + '\n' + knowledge.topics.join(' '), anchors, signal);
    signal.throwIfAborted();
    // Never inject a card that became invalid while awaiting retrieval.
    if (memories.hits.some(hit => !this.memory.readable(hit.card, run))) throw new DomainError('stale', '检索期间记忆已修订');
    run.memoryReads = memories.hits.map(hit => ({ id: hit.card.id, revision: hit.card.revision }));
    if (!this.memory.engine.memory.validReads(run.memoryReads)) throw new DomainError('stale', '检索期间记忆版本已变化');
    run.knowledgeAnchors = anchors;
    let memoryBudget = 10000;
    const selected = memories.hits.filter(hit => {
      const length = JSON.stringify(hit.card).length;
      if (length > memoryBudget) return false;
      memoryBudget -= length; return true;
    });
    // Only actual context dependencies should invalidate this run.
    run.memoryReads = selected.map(hit => ({ id: hit.card.id, revision: hit.card.revision }));
    this.memory.engine.bindMemoryContext(run);
    if (selected.length < memories.hits.length) memories.warnings.push('上下文预算不足，已整条省略部分记忆，可通过管理页查看原始来源');
    return {
      taskGoal: run.task.grant.channel?.kind === 'management' || run.task.revision > 1 ? run.task.goal : latest,
      currentRequest: latest, courseProgress: run.course.progress,
      previousAnswer: earlier.length ? run.task.result?.slice(0, 2500) : undefined,
      discussion: current?.quoted ? discussion : discussion.filter(e => e.eventId === current?.id || recent.some(i => i.event.id === e.eventId)),
      subject: this.memory.scope(run),
      exactTextbookReferences: exact?.requested.length ? exact : undefined,
      textbookEvidence: knowledge,
      studentMemory: { mode: memories.mode, warnings: memories.warnings, hits: selected.map(({ card, reasons }) => ({
        id: card.id, revision: card.revision, subjectId: card.subjectId, kind: card.kind, preference: card.preference,
        observation: card.observation, teaching: card.teaching, outcome: card.outcome,
        topics: card.topics, evidenceType: card.evidenceType, occurredAt: card.occurredAt, sources: card.sources, reasons,
      })) },
    };
  }
}
