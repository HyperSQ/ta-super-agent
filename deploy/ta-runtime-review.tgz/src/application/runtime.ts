import { Router } from '../agents/router.ts';
import { TaskRunner } from './task-runner.ts';
import { DeliveryOutbox } from './delivery-outbox.ts';
import { TaskEngine } from './task-engine.ts';
import type { ThreadClassifier } from '../agents/thread-classifier.ts';
import type { MemoryUpdater } from './memory-updater.ts';
import { inActivity, currentActivity } from './activities.ts';
import { WeeklyLesson } from './weekly-lesson.ts';

export class Runtime {
  engine: TaskEngine; router: Router; runner: TaskRunner; outbox: DeliveryOutbox;
  private routing = new Set<string>();
  private routeScopes = new Set<string>();
  private routeJobs = new Set<Promise<void>>();
  private controller = new AbortController();
  private timer?: ReturnType<typeof setInterval>;
  private sending?: Promise<void>;
  private reviewing = new Set<string>();
  classifier?: ThreadClassifier;
  memoryUpdater?: MemoryUpdater;
  private weekly: WeeklyLesson;
  constructor(engine: TaskEngine, router: Router, runner: TaskRunner, outbox: DeliveryOutbox, classifier?: ThreadClassifier, memoryUpdater?: MemoryUpdater) {
    this.engine = engine; this.router = router; this.runner = runner; this.outbox = outbox;
    this.classifier = classifier;
    this.memoryUpdater = memoryUpdater;
    this.weekly = new WeeklyLesson(engine, router.model);
  }
  start(): void {
    this.engine.recover(); this.tick();
    this.timer = setInterval(() => this.tick(), 100);
  }
  tick(): void {
    if (this.controller.signal.aborted) return;
    this.engine.recoverRuns();
    this.engine.refreshMemoryContexts();
    this.weekly.tick();
    if (this.classifier) for (const event of this.engine.store.pendingReviews()) {
      if (this.reviewing.size >= 2) break;
      if (this.reviewing.has(event.id)) continue;
      this.reviewing.add(event.id);
      const job = inActivity(this.engine.store, { node: 'router', courseId: event.courseId, eventId: event.id }, async () => {
        currentActivity('review.start', '开始线程复核');
        await this.classifier!.reconsider(event.id, this.controller.signal);
        currentActivity('review.finish', '结束线程复核', this.engine.store.assignment(event.id));
      }).catch(error => {
        if (!this.controller.signal.aborted) {
          this.engine.store.markRouted(event.id, error instanceof Error ? error.message : '线程复核失败');
          this.engine.store.audit('thread.review_failed', { eventId: event.id });
        }
      }).finally(() => { this.reviewing.delete(event.id); this.routeJobs.delete(job); });
      this.routeJobs.add(job);
    }
    // Distinct source conversations can route in parallel; only a few plans at once.
    for (const event of this.engine.store.pendingEvents()) {
      if (this.routing.size >= 4) break;
      if (this.routing.has(event.id)) continue;
      const scope = this.engine.policy.isTeacher(event.actor.id) ? `teacher-course:${event.courseId}` : `thread:${event.threadId}`;
      if (this.routeScopes.has(scope)) continue;
      this.routing.add(event.id);
      this.routeScopes.add(scope);
      const job = inActivity(this.engine.store, { node: 'router', courseId: event.courseId, eventId: event.id }, async () => {
        currentActivity('route.start', '进入 Router');
        try {
          await this.router.route(event, this.controller.signal);
          currentActivity('route.finish', 'Router 处理完成');
        } catch (error) {
          currentActivity('route.error', 'Router 处理失败', { error: error instanceof Error ? error.message : String(error) });
          throw error;
        }
      }).catch(error => {
        if (!this.controller.signal.aborted) {
          this.engine.store.markRouted(event.id, error instanceof Error ? error.message : '路由失败');
          this.engine.store.audit('routing.failed', { eventId: event.id, error: error instanceof Error ? error.message : '路由失败' });
        }
      }).finally(() => { this.routing.delete(event.id); this.routeScopes.delete(scope); this.routeJobs.delete(job); });
      this.routeJobs.add(job);
    }
    this.runner.tick();
    this.memoryUpdater?.tick();
    if (!this.sending) {
      this.sending = this.outbox.tick().catch(error => { this.engine.store.audit('delivery.failed', { error: error instanceof Error ? error.message : '交付失败' }); }).finally(() => { this.sending = undefined; });
    }
  }
  async stop(): Promise<void> {
    clearInterval(this.timer); this.controller.abort(new Error('服务停止'));
    await Promise.all([...this.routeJobs, this.runner.stop(), this.sending, this.memoryUpdater?.stop(), this.weekly.stop()]);
  }
}
