import { createHash } from 'node:crypto';
import { harnessPackage } from './harness.js';
import { withBridge } from './transport.js';

const { defineTool } = await harnessPackage('@deepseek-ai/dsh-tools');
export const name = 'ta-super-agent-tools';
export const inject = ['tools', 'taSuperAgentConnection', 'userQuestions'];
const field = description => ({ type: 'string', required: true, description });

export function apply(ctx) {
  const bridge = (exec, operation) => withBridge(ctx.get('taSuperAgentConnection')(), exec.signal, operation);
  const register = (name, description, parameters, execute) => ctx.tools.register(defineTool({
    name, description, parameters,
    output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
    async execute(args, exec) { return JSON.stringify(await execute(args, exec)); },
  }));
  register('ta_courses', '在用户要使用服务器助教能力时查询其课程编号。普通本地工作无需调用。', {},
    (_args, exec) => bridge(exec, api => api('GET', '/v1/dsh/courses')));
  register('ta_assignments', '查看指定课程已保存的作业、截止时间与题目。仅在用户需要读取服务器资料时调用。', {
    courseId: field('课程 ID'),
  }, ({ courseId }, exec) => bridge(exec, api => api('GET', '/v1/dsh/courses/' + encodeURIComponent(courseId) + '/assignments')));
  register('ta_contact', '仅在用户要求联系服务器助教、或确认要交给服务器处理时调用。将最少必要内容交给服务器 Router，返回事件编号供 ta_request_status 查询。', {
    courseId: field('课程 ID'), request: field('用户授权转交的具体问题'),
  }, ({ courseId, request }, exec) => {
    const requestId = createHash('sha256').update(String(exec.agent.session.id) + '\0' + String(exec.callId)).digest('hex');
    return bridge(exec, api => api('POST', '/v1/dsh/requests', { courseId, request, requestId }));
  });
  register('ta_request_status', '查看服务器助教请求、答疑结果或作业派发回执。', { eventId: field('桥接返回的事件 ID') },
    ({ eventId }, exec) => bridge(exec, api => api('GET', '/v1/dsh/requests/' + encodeURIComponent(eventId))));
  register('ta_dispatch_assignment', '仅在用户要求向课程 QQ 群派发某份现有作业时使用。工具会展示服务器生成的通知原文和目标群，由用户本人确认后提交 Router。', {
    courseId: field('课程 ID'), assignmentId: field('已保存、学生可见的作业 ID'),
  }, async (args, exec) => {
    const preview = await bridge(exec, api => api('POST', '/v1/dsh/announcement/preview', args));
    const decision = await ctx.userQuestions.ask({
      agent: exec.agent, signal: exec.signal,
      questions: [{ id: 'ta-dispatch', header: '派发作业', question: `确认发送到课程 QQ 群 ${preview.groupId}？`,
        detail: preview.text, options: [{ label: '确认派发' }, { label: '取消' }],
        intent: { kind: 'approval', approve: '确认派发', reject: '取消' } }],
    });
    if (decision.answers.find(answer => answer.id === 'ta-dispatch')?.selected[0] !== '确认派发') return { status: 'cancelled' };
    return bridge(exec, api => api('POST', '/v1/dsh/announcement/confirm', { confirmation: preview.confirmation }));
  });
}
